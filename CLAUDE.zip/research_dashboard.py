"""
MR MIKE — Research Dashboard
Run with:  streamlit run research_dashboard.py
"""

import streamlit as st
import os, re, subprocess
from datetime import datetime
from pathlib import Path
from collections import defaultdict

# ── config ───────────────────────────────────────────────────────
BASE = Path(__file__).parent
REFRESH_SECS = 30

st.set_page_config(
    page_title="Mr Mike — Research Dashboard",
    page_icon="🔬",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── global CSS ────────────────────────────────────────────────────
st.markdown("""
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Cormorant+Garamond:wght@400;600&display=swap');

  /* ── Base ── */
  html, body, [class*="css"] { font-family: 'Inter', sans-serif; }
  .main  { background: #07090F !important; }
  .block-container { padding: 1.5rem 2.5rem 3rem 2.5rem; }

  /* ── Custom scrollbar ── */
  ::-webkit-scrollbar { width: 5px; }
  ::-webkit-scrollbar-track { background: #07090F; }
  ::-webkit-scrollbar-thumb { background: #C9A84C; border-radius: 10px; }

  /* ── Page headings ── */
  h1, h2, h3, .stMarkdown h3 { color: #FFFFFF !important; letter-spacing: .3px; }

  /* ── Stat cards — white boxes ── */
  .stat-box {
    background: #FFFFFF;
    border-radius: 16px;
    padding: 20px 14px;
    box-shadow: 0 4px 24px rgba(0,0,0,.45);
    text-align: center;
    border-top: 4px solid;
    position: relative;
    overflow: hidden;
  }
  .stat-box::after {
    content: '';
    position: absolute;
    bottom: 0; left: 0; right: 0; height: 1px;
    background: linear-gradient(90deg, transparent, rgba(201,168,76,.4), transparent);
  }
  .stat-num { font-size: 2.1rem; font-weight: 700; line-height: 1; }
  .stat-lbl { font-size: .7rem; color: #555; margin-top: 5px;
               font-weight: 600; letter-spacing: .6px; text-transform: uppercase; }

  /* ── Category header ── */
  .cat-header {
    padding: 12px 18px; border-radius: 10px; color: #FFFFFF;
    font-weight: 700; font-size: .93rem; margin: 24px 0 12px 0;
    display: flex; align-items: center; gap: 10px;
    box-shadow: 0 4px 18px rgba(0,0,0,.35);
    letter-spacing: .3px;
  }

  /* ── File card — white boxes ── */
  .file-card {
    background: #FFFFFF;
    border-radius: 12px;
    padding: 13px 17px;
    margin-bottom: 10px;
    box-shadow: 0 2px 14px rgba(0,0,0,.3);
    border-left: 4px solid;
    transition: all .2s ease;
  }
  .file-card:hover {
    box-shadow: 0 6px 28px rgba(201,168,76,.25);
    transform: translateY(-2px);
  }
  .file-title { font-weight: 600; font-size: .88rem; color: #0D1B2A; }
  .file-meta  { font-size: .72rem; color: #777; margin-top: 4px; }

  /* ── Risk badges ── */
  .badge {
    display: inline-block; padding: 2px 9px; border-radius: 20px;
    font-size: .64rem; font-weight: 700; margin-left: 6px;
  }
  .badge-low      { background: #E8F8EE; color: #1E7F4E; }
  .badge-moderate { background: #FEF3E2; color: #D4620A; }
  .badge-high     { background: #FDEAEA; color: #B03030; }
  .badge-type     { background: #EEF2FF; color: #3949AB; }

  /* ── Sidebar ── */
  section[data-testid="stSidebar"] {
    background: #04060C !important;
    border-right: 1px solid rgba(201,168,76,.18) !important;
  }
  section[data-testid="stSidebar"] * { color: #E8E8E8 !important; }
  section[data-testid="stSidebar"] strong,
  section[data-testid="stSidebar"] b  { color: #C9A84C !important; }
  section[data-testid="stSidebar"] hr { border-color: rgba(201,168,76,.2) !important; }

  /* sidebar inputs */
  section[data-testid="stSidebar"] input {
    background: #0D1B2A !important;
    border: 1px solid rgba(201,168,76,.35) !important;
    border-radius: 8px !important;
    color: #FFFFFF !important;
  }
  section[data-testid="stSidebar"] input::placeholder { color: #666 !important; }

  /* sidebar multiselect */
  section[data-testid="stSidebar"] [data-baseweb="select"] > div {
    background: #0D1B2A !important;
    border: 1px solid rgba(201,168,76,.35) !important;
    border-radius: 8px !important;
    color: #FFFFFF !important;
  }
  /* tag chips inside multiselect */
  section[data-testid="stSidebar"] [data-baseweb="tag"] {
    background: rgba(201,168,76,.25) !important;
    border: 1px solid rgba(201,168,76,.5) !important;
  }

  /* sidebar refresh button */
  section[data-testid="stSidebar"] .stButton button {
    background: linear-gradient(135deg, #C9A84C 0%, #D4AF37 100%) !important;
    color: #07090F !important;
    border: none !important;
    font-weight: 700 !important;
    border-radius: 8px !important;
    letter-spacing: .4px;
  }
  section[data-testid="stSidebar"] .stButton button:hover {
    opacity: .88 !important;
  }

  /* sidebar radio */
  section[data-testid="stSidebar"] .stRadio label { color: #CCCCCC !important; }
  section[data-testid="stSidebar"] .stRadio [aria-checked="true"] + label {
    color: #C9A84C !important; font-weight: 600 !important;
  }

  /* ── Main area buttons ── */
  .stButton button {
    border-radius: 8px !important;
    font-size: .78rem !important;
    font-weight: 500 !important;
    background: rgba(201,168,76,.12) !important;
    border: 1px solid rgba(201,168,76,.35) !important;
    color: #C9A84C !important;
    transition: all .15s !important;
  }
  .stButton button:hover {
    background: rgba(201,168,76,.25) !important;
    border-color: #C9A84C !important;
  }

  /* ── Dividers ── */
  hr { border-color: rgba(201,168,76,.18) !important; margin: 8px 0 !important; }

  /* ── Info / alert boxes ── */
  .stAlert {
    background: rgba(201,168,76,.08) !important;
    border: 1px solid rgba(201,168,76,.28) !important;
    color: #E8E8E8 !important;
    border-radius: 10px !important;
  }

  /* ── Recently added card — white ── */
  .recent-card {
    background: #FFFFFF;
    border-radius: 10px;
    padding: 12px 16px;
    margin-bottom: 8px;
    border-left: 3px solid #C9A84C;
    box-shadow: 0 2px 12px rgba(0,0,0,.25);
  }

  /* ── code tag in footer ── */
  code { color: #C9A84C !important; background: transparent !important; }
</style>
""", unsafe_allow_html=True)

# ── constants ─────────────────────────────────────────────────────
SKIP_DIRS = {"BACK UP VERSION","Videos","PHOTOS","Articles","Fruits",
             "Natures Remss","Plants & Herbs That Destroy Cancer",
             "Top hair Shampoo in the world","Lost iPhone",
             "Photos of Main Door","Clean photos","01. VITAMINS"}

FILE_ICONS = {".pdf":"📄",".docx":"📝",".doc":"📝",".gdoc":"☁️",
              ".gsheet":"📊",".jpg":"🖼️",".jpeg":"🖼️",".png":"🖼️",
              ".avif":"🖼️",".mp4":"🎬",".mp3":"🎵",".xlsx":"📊"}

FOLDER_CAT = {
    # ── Herbal Products ──────────────────────────────────────────────────────
    "Ashwagandha":"Herbal Products","Black Seed Oil":"Herbal Products",
    "Cordyceps":"Herbal Products","Haritaki":"Herbal Products",
    "Shikakai":"Herbal Products","Shilajit":"Herbal Products",
    "Shungite":"Herbal Products","Spirulina":"Herbal Products",
    "01. Herbal Products & Botanicals":"Herbal Products",
    # ── Essential Oils ───────────────────────────────────────────────────────
    "02. Essential Oils":"Essential Oils",
    # ── Vitamins & Supplements ───────────────────────────────────────────────
    "03. Vitamins & Supplements":"Vitamins & Supplements",
    "Magnesium":"Vitamins & Supplements",
    "14. Advanced Supplements":"Vitamins & Supplements",
    "19. L-Lysine & Amino Acids":"Vitamins & Supplements",
    # ── Dental Health ────────────────────────────────────────────────────────
    "04. Dental Health":"Dental Health",
    # ── Medicine ────────────────────────────────────────────────────────────
    "05. Pharmaceutical & Medicine":"Medicine",
    "18. Ivermectin Research":"Medicine",
    # ── Biohacking ──────────────────────────────────────────────────────────
    "06. Grounding & Earthing Technology":"Biohacking",
    "04. Grounding Sheets & Earthing":"Biohacking",
    # ── Natural Products ────────────────────────────────────────────────────
    "07. Dr. Abas Mazni - Natural Remedies":"Natural Products",
    # ── Nutrition ───────────────────────────────────────────────────────────
    "08. Nutrition - Fruits & Food Therapy":"Nutrition",
    "09. Ghee & Healthy Fats":"Nutrition",
    "10. Green Juice & Superfoods":"Nutrition",
    "16. Medicinal Teas & Herbal Infusions":"Nutrition",
    "Oil of Oregano & Black Seed Oil":"Nutrition",
    "Olive oil":"Nutrition",
    "06. Therapeutic Oils & Natural Extracts":"Nutrition",
    # ── Personal Care ────────────────────────────────────────────────────────
    "11. Hair Care & Shampoo Analysis":"Personal Care",
    "02. Personal Care & Hygiene Products":"Personal Care",
    "Hair Control PP405":"Personal Care",
    "Pharmacopia Verbena Body Wash":"Personal Care",
    "BRESIH - Natural Cleaning Products":"Personal Care",
    "13. Topical Sprays & Suncare":"Personal Care",
    # ── Plants & Environment ─────────────────────────────────────────────────
    "12. Natural Health Plants & Air Purification":"Plants & Environment",
    # ── Chemicals ────────────────────────────────────────────────────────────
    "15. Chemical Exposure & Toxicology":"Chemicals",
    "17. Borax Research":"Chemicals",
    # ── Medical Science ──────────────────────────────────────────────────────
    "20. Biomarkers & Diagnostics":"Medical Science",
    # ── Environment ──────────────────────────────────────────────────────────
    "23. Water Quality & Hydration":"Environment",
    # ── Skincare ─────────────────────────────────────────────────────────────
    "10. Skincare & Toxicology Analysis":"Skincare",
    # ── Home ─────────────────────────────────────────────────────────────────
    "03. Home Cleaning & Maintenance":"Home",
    # ── Travel ───────────────────────────────────────────────────────────────
    "04. Travel & Flight Intelligence":"Travel",
    # ── Home Development ─────────────────────────────────────────────────────
    "05. Home Development & Smart Living":"Home Development",
    "01. Solar Energy Systems":"Home Development",
    "02. Swimming Pool Health & Technology":"Home Development",
    "03. Faraday Cage & EMF Protection":"Home Development",
    "05. Tower Garden & Vertical Farming":"Home Development",
    "06. Kitchen Equipment & Cookware":"Home Development",
    "07. Interior Lighting & Shelf Design":"Home Development",
    "08. Indowud - Composite Building Materials":"Home Development",
    "09. Construction & Sustainable Materials":"Home Development",
    # ── Business ─────────────────────────────────────────────────────────────
    "07. Business & Market Intelligence":"Business",
    # ── Technology ───────────────────────────────────────────────────────────
    "08. Technology & Smart Devices":"Technology",
    "01. iPhone Security & Optimization":"Technology",
    "02. PLAUD - AI Voice Recording":"Technology",
    "03. Easy Expense - Expense Management":"Technology",
    "04. Zilkee - Recovery Converter":"Technology",
    "05. Proton Mail - Privacy & Security":"Technology",
    "06. Eufy by Anker - Smart Home Security":"Technology",
    "07. Phone Intelligence & OSINT Tools":"Technology",
    "08. Smart Switches & Home Automation":"Technology",
    "09. Litecard - Digital Business Card":"Technology",
    # ── Automotive ───────────────────────────────────────────────────────────
    "09. Automotive Research":"Automotive",
    # ── Reference ────────────────────────────────────────────────────────────
    "22. Reference - Scientific Evidence":"Reference",
    "_Reference & Index":"Reference",
    # ── Misc / Lifestyle ─────────────────────────────────────────────────────
    "21. Miscellaneous Health":"Misc",
    "11. Lifestyle & Mindset":"Lifestyle",
    "12 Law of Karma you should know":"Lifestyle",
}

CAT_COLORS = {
    "Herbal Products":"#1E7F4E","Essential Oils":"#117A65",
    "Vitamins & Supplements":"#1A5276","Dental Health":"#6C3483",
    "Medicine":"#B03030","Biohacking":"#283593",
    "Natural Products":"#6B6E29","Nutrition":"#0E7490",
    "Personal Care":"#922B5E","Plants & Environment":"#2D6A4F",
    "Chemicals":"#D4620A","Medical Science":"#1A5276",
    "Environment":"#117A65","Skincare":"#922B5E",
    "Home":"#2E4057","Home Development":"#2E4057",
    "Travel":"#1A5276","Business":"#7E5109",
    "Technology":"#0D1B2A","Automotive":"#2E4057",
    "Misc":"#555","Lifestyle":"#C9A84C",
    "Reference":"#888","Uncategorised":"#AAA",
}

CAT_EMOJI = {
    "Herbal Products":"🌿","Essential Oils":"🫙","Vitamins & Supplements":"💊",
    "Dental Health":"🦷","Medicine":"💉","Biohacking":"⚡",
    "Natural Products":"🍃","Nutrition":"🥑","Personal Care":"🧴",
    "Plants & Environment":"🌱","Chemicals":"⚗️","Medical Science":"🔬",
    "Environment":"💧","Skincare":"✨","Home":"🏠",
    "Home Development":"🏗️","Travel":"✈️","Business":"📊",
    "Technology":"💻","Automotive":"🚗","Misc":"📁",
    "Lifestyle":"☀️","Reference":"📌","Uncategorised":"❓",
}

RISK_MAP = {
    "haritaki_fluoride_pineal": ("MODERATE","Use with Limitation"),
    "purejit_shilajit":         ("MODERATE","Use with Caution"),
    "nitric_oxide":             ("LOW","Safe to Use"),
    "nitric oxide":             ("LOW","Safe to Use"),
    "moringa_risk":             ("LOW","Recommended"),
    "beetroot_risk":            ("LOW","Recommended"),
    "beetroot_ complete":       ("LOW","Recommended"),
    "acidic_bonding_toxicity":  ("MODERATE","Use with Caution"),
    "coconut_jasmine_toxicity": ("LOW","Use with Care"),
    "eye_cream_toxicity":       ("MODERATE","Use with Caution"),
    "gliss_ultimate_repair":    ("MODERATE","Use with Caution"),
    "cork_construction":        ("LOW","Recommended"),
    "translucent_concrete":     ("MODERATE","Use with Caution"),
    "paper_bottle_business":    ("MODERATE","Viable Opportunity"),
    "watercress":               ("LOW","Recommended"),
    "spirulina":                ("LOW","Recommended"),
    "shungite":                 ("MODERATE","Use with Caution"),
    "faraday cage":             ("LOW","Informational"),
    "methylene blue":           ("MODERATE","Consult Doctor"),
    "borax":                    ("MODERATE","Use with Caution"),
    "swimming in chlorinated":  ("MODERATE","Use with Caution"),
    "saltwater swimming":       ("LOW","Recommended"),
    "ozone systems":            ("LOW","Recommended"),
    "hayward aquarite":         ("LOW","Recommended"),
    "ashwagandha":              ("LOW","Recommended"),
}

# ── helpers ───────────────────────────────────────────────────────
def get_category(filepath: Path) -> str:
    parts = filepath.relative_to(BASE).parts
    for p in reversed(parts[:-1]):
        if p in FOLDER_CAT:
            return FOLDER_CAT[p]
    for p in parts[:-1]:
        if p in FOLDER_CAT:
            return FOLDER_CAT[p]
    return "Uncategorised"

def get_risk(name: str):
    n = name.lower()
    for k, v in RISK_MAP.items():
        if k in n:
            return v
    return ("", "")

def clean_name(fname: str) -> str:
    stem = Path(fname).stem
    n = re.sub(r"[_\-]+"," ", stem)
    n = re.sub(r"\s+"," ", n).strip()
    words = []
    for w in n.split():
        words.append(w if (w.isupper() and len(w) > 1) or w.isdigit() else w.capitalize())
    return " ".join(words)

def file_icon(fname: str) -> str:
    return FILE_ICONS.get(Path(fname).suffix.lower(), "📄")

def open_file(path: Path):
    try:
        os.startfile(str(path))
    except Exception:
        subprocess.Popen(["explorer", str(path)])

def open_folder(path: Path):
    try:
        subprocess.Popen(["explorer", str(path.parent)])
    except Exception:
        pass

# ── scanner ───────────────────────────────────────────────────────
@st.cache_data(ttl=REFRESH_SECS)
def scan_files():
    records = []
    for dirpath, dirnames, filenames in os.walk(BASE):
        dirnames[:] = [d for d in sorted(dirnames)
                       if d not in SKIP_DIRS and not d.startswith(".")]
        for fname in sorted(filenames):
            if fname.startswith(".") or fname == "desktop.ini": continue
            fp = Path(dirpath) / fname
            try:
                mtime = datetime.fromtimestamp(fp.stat().st_mtime)
            except Exception:
                continue
            risk, rec = get_risk(fname)
            cat = get_category(fp)
            rel = str(fp.relative_to(BASE))
            records.append({
                "path":   fp,
                "rel":    rel,
                "fname":  fname,
                "name":   clean_name(fname),
                "ext":    fp.suffix.lower(),
                "icon":   file_icon(fname),
                "cat":    cat,
                "risk":   risk,
                "rec":    rec,
                "date":   mtime,
                "date_s": mtime.strftime("%d %b %Y"),
                "is_report": bool(risk) or any(
                    k in fname.lower() for k in
                    ["report","brief","research","analysis","toxicity","assessment","guide"]),
            })
    records.sort(key=lambda x: x["date"], reverse=True)
    return records

# ── sidebar ───────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style='text-align:center; padding: 20px 0 10px 0;'>
      <div style='font-size:2rem;'>🔬</div>
      <div style='font-size:1.1rem; font-weight:700; color:#C9A84C;'>Mr Mike</div>
      <div style='font-size:.8rem; color:#9A7A3A; margin-top:2px; letter-spacing:.8px; text-transform:uppercase;'>Research Dashboard</div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")
    search = st.text_input("🔍 Search files...", placeholder="Type to search...")

    st.markdown("**Filter by Category**")
    all_cats = sorted(CAT_COLORS.keys())
    selected_cats = st.multiselect("Filter by Category", all_cats, placeholder="All categories", label_visibility="collapsed")

    st.markdown("**Filter by Risk Level**")
    risk_filter = st.multiselect("Filter by Risk Level", ["LOW","MODERATE","HIGH","Reports Only"],
                                  placeholder="All risk levels", label_visibility="collapsed")

    st.markdown("**File Type**")
    type_filter = st.multiselect("Filter by File Type", ["📄 PDF","📝 Word","☁️ GDoc","📊 Sheets","🖼️ Image","🎬 Video"],
                                  placeholder="All types", label_visibility="collapsed")

    st.markdown("---")
    view_mode = st.radio("View Mode", ["📂 By Category","📋 All Files","🆕 Recently Added","🔬 Risk Reports"])
    st.markdown("---")
    if st.button("🔄  Refresh Now", use_container_width=True):
        st.cache_data.clear()
        st.rerun()
    st.markdown(f"<div style='font-size:.7rem;color:#9A7A3A;text-align:center;margin-top:6px;letter-spacing:.4px;'>Auto-refreshes every {REFRESH_SECS}s</div>",
                unsafe_allow_html=True)

# ── load data ─────────────────────────────────────────────────────
records = scan_files()

# apply filters
filtered = records[:]
if search:
    q = search.lower()
    filtered = [r for r in filtered if q in r["name"].lower() or q in r["cat"].lower() or q in r["rel"].lower()]
if selected_cats:
    filtered = [r for r in filtered if r["cat"] in selected_cats]
if risk_filter:
    def risk_match(r):
        if "Reports Only" in risk_filter:
            return r["is_report"]
        return r["risk"] in risk_filter
    filtered = [r for r in filtered if risk_match(r)]
if type_filter:
    ext_map = {"📄 PDF":[".pdf"],"📝 Word":[".docx",".doc"],"☁️ GDoc":[".gdoc"],
               "📊 Sheets":[".gsheet",".xlsx"],"🖼️ Image":[".jpg",".jpeg",".png",".avif"],
               "🎬 Video":[".mp4"]}
    allowed = []
    for tf in type_filter:
        allowed += ext_map.get(tf,[])
    filtered = [r for r in filtered if r["ext"] in allowed]

# ── stats bar ─────────────────────────────────────────────────────
cats_in_filtered = set(r["cat"] for r in filtered)
reports_in_filtered = sum(1 for r in filtered if r["is_report"])
low = sum(1 for r in filtered if r["risk"]=="LOW")
mod = sum(1 for r in filtered if r["risk"]=="MODERATE")
hig = sum(1 for r in filtered if r["risk"]=="HIGH")

st.markdown("""
<div style='display:flex; gap:14px; margin-bottom:18px; flex-wrap:wrap;'>
""", unsafe_allow_html=True)

c1,c2,c3,c4,c5,c6 = st.columns(6)
for col, num, label, border in [
    (c1, len(filtered),          "Total Files",   "#0D1B2A"),
    (c2, len(cats_in_filtered),  "Categories",    "#C9A84C"),
    (c3, reports_in_filtered,    "Reports",       "#1A5276"),
    (c4, low,                    "✅ Low Risk",    "#1E7F4E"),
    (c5, mod,                    "⚠️ Moderate",   "#D4620A"),
    (c6, hig,                    "🔴 High Risk",   "#B03030"),
]:
    col.markdown(f"""
    <div class="stat-box" style="border-top-color:{border}">
      <div class="stat-num" style="color:{border}">{num}</div>
      <div class="stat-lbl">{label}</div>
    </div>""", unsafe_allow_html=True)

st.markdown("<div style='height:8px'></div>", unsafe_allow_html=True)

# ── file card renderer ────────────────────────────────────────────
def risk_badge(risk):
    if risk == "LOW":
        return f'<span class="badge badge-low">✅ LOW</span>'
    elif risk == "MODERATE":
        return f'<span class="badge badge-moderate">⚠️ MODERATE</span>'
    elif risk == "HIGH":
        return f'<span class="badge badge-high">🔴 HIGH</span>'
    return ""

def render_file_card(r, col, border_color):
    with col:
        risk_html = risk_badge(r["risk"])
        ext_label = r["ext"].replace(".","").upper()
        rel_short = "/".join(str(r["rel"]).split(os.sep)[-3:])
        st.markdown(f"""
        <div class="file-card" style="border-left-color:{border_color}">
          <div class="file-title">{r['icon']} {r['name']}{risk_html}
            <span class="badge badge-type">{ext_label}</span>
          </div>
          <div class="file-meta">📁 .../{rel_short} &nbsp;·&nbsp; 🗓 {r['date_s']}</div>
          {f'<div class="file-meta" style="color:#D4620A;font-weight:600;margin-top:3px;">→ {r["rec"]}</div>' if r["rec"] else ""}
        </div>""", unsafe_allow_html=True)

        btn_col1, btn_col2 = st.columns([1,1])
        with btn_col1:
            if st.button("📂 Open File", key=f"open_{r['rel']}", use_container_width=True):
                open_file(r["path"])
        with btn_col2:
            if st.button("🗂 Folder", key=f"folder_{r['rel']}", use_container_width=True):
                open_folder(r["path"])

# ── VIEW: BY CATEGORY ─────────────────────────────────────────────
if view_mode == "📂 By Category":
    st.markdown(f"### 📂 Research by Category")
    if not filtered:
        st.info("No files match your search or filters.")
    else:
        by_cat = defaultdict(list)
        for r in filtered:
            by_cat[r["cat"]].append(r)

        for cat in sorted(by_cat.keys()):
            items = by_cat[cat]
            color = CAT_COLORS.get(cat,"#888")
            emoji = CAT_EMOJI.get(cat,"📁")
            reports = sum(1 for i in items if i["is_report"])

            st.markdown(f"""
            <div class="cat-header" style="background:{color}">
              {emoji} {cat}
              <span style="margin-left:auto;font-size:.8rem;font-weight:400;opacity:.85">
                {len(items)} files · {reports} reports
              </span>
            </div>""", unsafe_allow_html=True)

            cols = st.columns(2)
            for idx, r in enumerate(items):
                render_file_card(r, cols[idx % 2], color)
            st.markdown("<div style='height:4px'></div>", unsafe_allow_html=True)

# ── VIEW: ALL FILES ───────────────────────────────────────────────
elif view_mode == "📋 All Files":
    st.markdown(f"### 📋 All Files ({len(filtered)})")
    sorted_filtered = sorted(filtered, key=lambda x: (x["cat"], x["name"]))
    cols = st.columns(2)
    for idx, r in enumerate(sorted_filtered):
        color = CAT_COLORS.get(r["cat"],"#888")
        render_file_card(r, cols[idx % 2], color)

# ── VIEW: RECENTLY ADDED ──────────────────────────────────────────
elif view_mode == "🆕 Recently Added":
    st.markdown("### 🆕 Recently Added Files")
    recent = sorted(filtered, key=lambda x: x["date"], reverse=True)[:50]
    if not recent:
        st.info("No files found.")
    else:
        for r in recent:
            color = CAT_COLORS.get(r["cat"],"#888")
            emoji = CAT_EMOJI.get(r["cat"],"📁")
            risk_html = risk_badge(r["risk"])
            c1, c2 = st.columns([5, 1])
            with c1:
                st.markdown(f"""
                <div class="recent-card">
                  <div class="file-title">{r['icon']} {r['name']}{risk_html}</div>
                  <div class="file-meta">
                    {emoji} {r['cat']} &nbsp;·&nbsp; 📁 {r['rel'].split(os.sep)[-2] if os.sep in r['rel'] else 'Root'}
                    &nbsp;·&nbsp; 🗓 {r['date_s']}
                  </div>
                </div>""", unsafe_allow_html=True)
            with c2:
                st.markdown("<div style='margin-top:6px'></div>", unsafe_allow_html=True)
                if st.button("Open", key=f"rec_{r['rel']}", use_container_width=True):
                    open_file(r["path"])

# ── VIEW: RISK REPORTS ────────────────────────────────────────────
elif view_mode == "🔬 Risk Reports":
    st.markdown("### 🔬 Risk Reports & Research Briefs")
    risk_records = [r for r in filtered if r["is_report"]]

    if not risk_records:
        st.info("No reports match current filters.")
    else:
        for level, label, section_color in [
            ("HIGH",     "🔴 HIGH RISK",     "#B03030"),
            ("MODERATE", "🟠 MODERATE RISK",  "#D4620A"),
            ("LOW",      "🟢 LOW RISK",       "#1E7F4E"),
            ("",         "📄 Unrated Reports", "#555"),
        ]:
            group = [r for r in risk_records if r["risk"] == level]
            if not group: continue

            st.markdown(f"""
            <div class="cat-header" style="background:{section_color}">
              {label} &nbsp;·&nbsp;
              <span style="font-size:.8rem;font-weight:400">{len(group)} reports</span>
            </div>""", unsafe_allow_html=True)

            cols = st.columns(2)
            for idx, r in enumerate(sorted(group, key=lambda x: x["name"])):
                render_file_card(r, cols[idx % 2], section_color)

# ── footer ────────────────────────────────────────────────────────
st.markdown("---")
st.markdown(f"""
<div style='text-align:center;font-size:.75rem;color:#6B6B6B;padding:8px 0;'>
  Mr Mike Research Dashboard &nbsp;·&nbsp; Scanning: <code>{BASE}</code>
  &nbsp;·&nbsp; Auto-refresh every {REFRESH_SECS}s
  &nbsp;·&nbsp; {len(records)} total files indexed
</div>""", unsafe_allow_html=True)

# ── auto-refresh ──────────────────────────────────────────────────
import time
time.sleep(REFRESH_SECS)
st.rerun()
